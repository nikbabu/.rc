$ codeset=UTF-8

$set 1 #Align

1 Äîëó â Ñðåäàòà
2 Äîëó â Ëÿâî
3 Äîëó â Äÿñíî
4 Õîðèçîíòàëíî
6 Äîëó â Ëÿâî
7 Ëÿâî â Ñðåäàòà
8 Ãîðå â Ëÿâî
11 Äîëó â Äÿñíî
12 Äÿñíî â Ñðåäàòà
13 Ãîðå â Äÿñíî
14 Ãîðå â Ñðåäàòà
15 Ãîðå â Ëÿâî
16 Ãîðå â Äÿñíî
17 Âåðòêàëíî

$set 2 #BaseDisplay


$set 3 #Common

2 Àâòîìàòè÷íî ñêðèâàíå

$set 4 #Configmenu

2 Àâòîìàòè÷íî Ïîâäèãàíå
4 Êëèêíè çà Ôîêóñ
7 Ôîêóñèðàé Ïðîçîðåö ïðè ñìÿíà íà Ðàáîòíèòå Ìåñòà
8 Òèï ôîêóñ
9 Ôîêóñèðàé Íîâèòå Ïðîçîðöè
10 Ïúëíî Óâåëè÷àâàíå
11 Image Dithering
12 Íåïðîçðà÷íî ìåñòåíå íà ïðîçîðöèòå
13 Ïîëó Sloppy Ôîêóñ
14 Sloppy Ôîêóñ
15 Workspace Warping

$set 5 #Ewmh


$set 6 #FbTkError


$set 7 #Fluxbox


$set 8 #Gnome


$set 9 #Keys


$set 10 #Menu

3 Èçõîä
4 Èêîíè
7 Ðàçïîëîæåíèå
9 Ðåñòàðòèðàíå

$set 11 #Remember


$set 12 #Screen

2 W: %4d x H: %4d
4 W: %04d x H: %04d

$set 13 #Slit

4 Posoka na Slit -a
7 Ðàçïîëîæåíèå íà Slit -à
8 Slit

$set 14 #Toolbar

1 Ðåäàêòèðàé èìåòî íà òåêóùîòî Ðàáîòíî Ìÿñòî
10 Ðàçïîëîæåíèå íà Toolbar -à
11 Toolbar

$set 15 #Window

1 Áåçèìå

$set 16 #Windowmenu

1 Çàòâîðè
2 Èêîíèçèðàé
4 Ñíèøè
5 Óâåëè÷è
6 Ïîâäèãíè
7 Ïðàòè íà ...
8 Çàñåí÷è
9 Çàáîäè

$set 17 #Workspace

1 Ðàáîòíî Ìÿñòî %d
2 Ðàáîòíè Ìåñòà
3 Íîâî Ðàáîòíî Ìÿñòî
4 Ìàõíè Ïîñëåäíîòî

$set 18 #fbsetroot

1 error: must specify one of: -solid, -mod, -gradient\n
3 -display <string>        display connection\n\
-mod <x> <y>             modula pattern\n\
-foreground, -fg <color> modula foreground color\n\
-background, -bg <color> modula background color\n\n\
-gradient <texture>      gradient texture\n\
-from <color>            gradient start color\n\
-to <color>              gradient end color\n\n\
-solid <color>           solid color\n\n\
-help                    print this help text and exit\n

$set 19 #main

1 ãðåøêà: '-display' èçèñêâà àðãóìåíò
11 ãðåøêà: '-rc' èçèñêâà àðãóìåíò
13 Fluxkbox %s: (c) %s Henrik Kinnunen\n\n\
-display <string>\t\tuse display connection.\n\
-rc <string>\t\t\tïîëçâàé çàìåñòâàù ðåñóðñåí ôàéë.\n\
-version\t\t\tïîêàæè âåðñèÿòà è èçëåç.\n\
-info\t\t\t\tdisplay some useful information.\n\
-log <filename>\t\t\tlog output to file.\n\
-help\t\t\t\tïîêàæè òîçè ïîìîùåí òåêñò è èçëåç.\n\n


