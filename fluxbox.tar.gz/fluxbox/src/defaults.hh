// This file is generated from Makefile. Do not edit!
#include <string>

#ifdef _WIN32
#define DUMMYPREFIX "/DUMMYPREFIX"
#define PATHPREFIX DUMMYPREFIX
#else
#define PATHPREFIX
#endif
#define DEFAULTMENU PATHPREFIX "/users/nikbabu/share/fluxbox/menu"
#define DEFAULTSTYLE PATHPREFIX "/users/nikbabu/share/fluxbox/styles/bloe"
#define DEFAULTKEYSFILE PATHPREFIX "/users/nikbabu/share/fluxbox/keys"
#define DEFAULT_APPSFILE PATHPREFIX "/users/nikbabu/share/fluxbox/apps"
#define DEFAULT_OVERLAY PATHPREFIX "/users/nikbabu/share/fluxbox/overlay"
#define DEFAULT_INITFILE PATHPREFIX "/users/nikbabu/share/fluxbox/init"
#define DEFAULT_WINDOWMENU PATHPREFIX "/users/nikbabu/share/fluxbox/windowmenu"
#define PROGRAM_PREFIX ""
#define PROGRAM_SUFFIX ""
std::string realProgramName(const std::string& name);
const char* gitrevision();
