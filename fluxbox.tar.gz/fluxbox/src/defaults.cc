// This file is generated from Makefile. Do not edit!
#include "defaults.hh"

std::string realProgramName(const std::string& name) {
  return PROGRAM_PREFIX + name + PROGRAM_SUFFIX;
}

const char* gitrevision() {
  return "this_is_tar_ball_build";
}
